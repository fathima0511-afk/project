basls -mkdir "ex$1"
mkdir "ex$2"
mkdir "ex$3"
mkdir "ex$4"